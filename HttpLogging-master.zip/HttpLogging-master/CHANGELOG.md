Change Log
==========

## Version 1.0.2

_2016-04-23_

 * Release updated version of LoggingInterceptorOkHttp3 with correct packagename


## Version 1.0.1

_2016-01-22_

 * Correct packagename


## Version 1.0.0

_2016-01-21_

Initial release.
